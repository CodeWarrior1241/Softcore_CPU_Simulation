# ================================================================================
# BRAM Investigation - Questa Compilation Script
# ================================================================================
# This script compiles the BRAM IP and verification testbench
# ================================================================================

# Quit any existing simulation
quit -sim

# Save current directory
set investigation_dir [pwd]

# Paths
set vivado_base "$investigation_dir/.."
set vivado_questa_dir "$vivado_base/NEORV32_Simulation.ip_user_files/sim_scripts/questa"
set bram_ip_dir "$vivado_base/NEORV32_Simulation.gen/sources_1/bd/Top/ip/Top_QPSK_Snapshot_BRAM_0"

# Pre-compiled Xilinx simulation libraries
set XILINX_QUESTA_LIBS "C:/Work/Questa_Libraries_Vivado"

# Path to blk_mem_gen source (same as Vivado-generated compile.do uses)
set blk_mem_gen_src "$vivado_base/NEORV32_Simulation.gen/sources_1/bd/Top/ipshared/42f3/simulation/blk_mem_gen_v8_4.v"

# ================================================================================
# Setup Libraries
# ================================================================================

puts "=========================================="
puts "Setting up libraries..."
puts "=========================================="

# Copy the pre-compiled Xilinx modelsim.ini as base (contains all library mappings)
file copy -force $XILINX_QUESTA_LIBS/modelsim.ini modelsim.ini

# Create work library
if {[file exists work]} {
    vdel -all -lib work
}
vlib work
vmap work work

# Create blk_mem_gen library (compile from source like Vivado does)
if {[file exists blk_mem_gen_v8_4_12]} {
    vdel -all -lib blk_mem_gen_v8_4_12
}
vlib blk_mem_gen_v8_4_12
vmap blk_mem_gen_v8_4_12 blk_mem_gen_v8_4_12

# ================================================================================
# Compile blk_mem_gen from source (same as Vivado-generated script)
# ================================================================================

puts "=========================================="
puts "Compiling blk_mem_gen_v8_4 from source..."
puts "=========================================="

vlog -work blk_mem_gen_v8_4_12 -incr -mfcu "$blk_mem_gen_src"

# ================================================================================
# Compile BRAM IP
# ================================================================================

puts "=========================================="
puts "Compiling BRAM IP wrapper..."
puts "=========================================="

# Compile the BRAM Verilog wrapper
vlog -work work "$bram_ip_dir/sim/Top_QPSK_Snapshot_BRAM_0.v"

# ================================================================================
# Compile Testbench
# ================================================================================

puts "=========================================="
puts "Compiling Testbench..."
puts "=========================================="

vcom -2008 -work work "$investigation_dir/bram_verify_tb.vhd"

# ================================================================================
# Copy required files
# ================================================================================

puts "=========================================="
puts "Copying initialization files..."
puts "=========================================="

# Copy COE file for testbench to read
file copy -force "$vivado_base/sim/qpsk_bram_init.coe" "$investigation_dir/qpsk_bram_init.coe"

# Copy MIF file for BRAM behavioral model
file copy -force "$vivado_questa_dir/Top_QPSK_Snapshot_BRAM_0.mif" "$investigation_dir/Top_QPSK_Snapshot_BRAM_0.mif"

puts "=========================================="
puts "Compilation Complete!"
puts "=========================================="
puts ""
puts "To run the simulation, execute: do simulate.do"
puts ""

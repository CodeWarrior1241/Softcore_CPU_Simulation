-- ============================================================================
-- BRAM Verification Testbench
-- ============================================================================
-- Simple testbench to verify BRAM initialization in Questa simulation.
-- Reads all 1024 words from BRAM, compares against expected COE values,
-- and outputs results for QPSK constellation plotting.
-- ============================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;

entity bram_verify_tb is
end entity bram_verify_tb;

architecture sim of bram_verify_tb is

    -- Clock period
    constant CLK_PERIOD : time := 10 ns;  -- 100 MHz

    -- BRAM parameters
    constant BRAM_DEPTH : natural := 1024;  -- Number of QPSK samples
    constant ADDR_WIDTH : natural := 13;

    -- Signals for BRAM interface
    signal clk      : std_logic := '0';
    signal ena      : std_logic := '0';
    signal wea      : std_logic_vector(0 downto 0) := "0";
    signal addra    : std_logic_vector(12 downto 0) := (others => '0');
    signal dina     : std_logic_vector(31 downto 0) := (others => '0');
    signal douta    : std_logic_vector(31 downto 0);

    -- Test signals
    signal test_done    : boolean := false;
    signal error_count  : natural := 0;

    -- File handles
    file coe_file    : text;
    file output_file : text;

    -- Function to check if character is hex digit
    function is_hex_char(c : character) return boolean is
    begin
        case c is
            when '0' to '9' | 'A' to 'F' | 'a' to 'f' => return true;
            when others => return false;
        end case;
    end function;

    -- Function to convert hex string to std_logic_vector
    function hex_to_slv(hex_str : string; bits : natural) return std_logic_vector is
        variable result : std_logic_vector(bits-1 downto 0) := (others => '0');
        variable nibble : std_logic_vector(3 downto 0);
        variable idx    : natural := bits - 4;
    begin
        for i in hex_str'range loop
            case hex_str(i) is
                when '0' => nibble := x"0";
                when '1' => nibble := x"1";
                when '2' => nibble := x"2";
                when '3' => nibble := x"3";
                when '4' => nibble := x"4";
                when '5' => nibble := x"5";
                when '6' => nibble := x"6";
                when '7' => nibble := x"7";
                when '8' => nibble := x"8";
                when '9' => nibble := x"9";
                when 'A' | 'a' => nibble := x"A";
                when 'B' | 'b' => nibble := x"B";
                when 'C' | 'c' => nibble := x"C";
                when 'D' | 'd' => nibble := x"D";
                when 'E' | 'e' => nibble := x"E";
                when 'F' | 'f' => nibble := x"F";
                when others => nibble := x"0";
            end case;
            if idx <= bits - 4 then
                result(idx+3 downto idx) := nibble;
                if idx >= 4 then
                    idx := idx - 4;
                end if;
            end if;
        end loop;
        return result;
    end function;

begin

    -- Clock generation - simple continuous clock
    clk <= not clk after CLK_PERIOD / 2;

    -- Instantiate the BRAM under test
    uut: entity work.Top_QPSK_Snapshot_BRAM_0
        port map (
            clka  => clk,
            ena   => ena,
            wea   => wea,
            addra => addra,
            dina  => dina,
            douta => douta
        );

    -- Main test process
    test_proc: process
        variable line_in    : line;
        variable line_out   : line;
        variable hex_str    : string(1 to 8);
        variable first_char : character;
        variable expected   : std_logic_vector(31 downto 0);
        variable i_val      : signed(15 downto 0);
        variable q_val      : signed(15 downto 0);
        variable addr       : natural := 0;
        variable file_status : file_open_status;
    begin
        -- Wait for a few clocks first
        wait for CLK_PERIOD * 5;

        report "Opening COE file...";

        -- Open COE file for reading expected values
        file_open(file_status, coe_file, "qpsk_bram_init.coe", read_mode);
        if file_status /= open_ok then
            report "ERROR: Could not open qpsk_bram_init.coe" severity failure;
            wait;
        end if;

        -- Open output file for constellation data
        file_open(file_status, output_file, "qpsk_readback.csv", write_mode);
        if file_status /= open_ok then
            report "ERROR: Could not open qpsk_readback.csv for writing" severity failure;
            wait;
        end if;

        -- Write CSV header
        write(line_out, string'("addr,expected_hex,actual_hex,match,i_val,q_val"));
        writeline(output_file, line_out);

        report "Starting BRAM verification - reading " & integer'image(BRAM_DEPTH) & " words";

        -- Read values from COE and compare with BRAM
        -- Data lines start with hex digit (0-9, A-F), skip all other lines
        addr := 0;
        while not endfile(coe_file) and addr < BRAM_DEPTH loop
            readline(coe_file, line_in);

            -- Check if line has enough characters and starts with hex digit
            if line_in'length >= 8 then
                first_char := line_in(1);

                -- Only process lines starting with hex digit
                if is_hex_char(first_char) then
                    -- Read 8 hex characters directly
                    for i in 1 to 8 loop
                        hex_str(i) := line_in(i);
                    end loop;

                    expected := hex_to_slv(hex_str, 32);

                    -- Apply address and enable on rising edge
                    wait until rising_edge(clk);
                    addra <= std_logic_vector(to_unsigned(addr, ADDR_WIDTH));
                    ena <= '1';
                    wea <= "0";  -- Read mode

                    -- Wait for read latency (2 cycles: 1 for BRAM + 1 for output register)
                    wait until rising_edge(clk);
                    wait until rising_edge(clk);
                    wait until rising_edge(clk);

                    -- Extract I and Q values
                    i_val := signed(douta(15 downto 0));
                    q_val := signed(douta(31 downto 16));

                    -- Write to CSV file
                    write(line_out, integer'image(addr) & ",");
                    hwrite(line_out, expected);
                    write(line_out, string'(","));
                    hwrite(line_out, douta);
                    if douta = expected then
                        write(line_out, string'(",PASS,"));
                    else
                        write(line_out, string'(",FAIL,"));
                        error_count <= error_count + 1;
                        report "MISMATCH at addr " & integer'image(addr) &
                               ": expected 0x" & to_hstring(expected) &
                               ", got 0x" & to_hstring(douta)
                            severity warning;
                    end if;
                    write(line_out, integer'image(to_integer(i_val)) & ",");
                    write(line_out, integer'image(to_integer(q_val)));
                    writeline(output_file, line_out);

                    addr := addr + 1;
                end if;
            end if;
        end loop;

        ena <= '0';

        -- Close files
        file_close(coe_file);
        file_close(output_file);

        -- Report results
        report "=========================================";
        report "BRAM Verification Complete";
        report "Total samples read: " & integer'image(addr);
        report "Errors found: " & integer'image(error_count);
        if error_count = 0 then
            report "STATUS: PASSED" severity note;
        else
            report "STATUS: FAILED" severity error;
        end if;
        report "=========================================";
        report "Output written to qpsk_readback.csv";

        test_done <= true;

        -- Stop simulation
        std.env.stop;
        wait;
    end process;

end architecture sim;

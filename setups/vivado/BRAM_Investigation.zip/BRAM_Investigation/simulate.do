# ================================================================================
# BRAM Investigation - Questa Simulation Script
# ================================================================================

# Pre-compiled Xilinx simulation libraries
set XILINX_QUESTA_LIBS "C:/Work/Questa_Libraries_Vivado"

# Load the design with proper library references
vsim -t ns -voptargs="+acc" -L blk_mem_gen_v8_4_12 -modelsimini ./modelsim.ini work.bram_verify_tb

# Add waves
add wave -divider "Clock & Control"
add wave /bram_verify_tb/clk
add wave /bram_verify_tb/ena
add wave /bram_verify_tb/wea

add wave -divider "BRAM Interface"
add wave -radix unsigned /bram_verify_tb/addra
add wave -radix hexadecimal /bram_verify_tb/dina
add wave -radix hexadecimal /bram_verify_tb/douta

add wave -divider "Test Status"
add wave -radix unsigned /bram_verify_tb/error_count
add wave /bram_verify_tb/test_done

# Run simulation
puts "=========================================="
puts "Running BRAM verification..."
puts "=========================================="

run 100 us

puts "=========================================="
puts "Simulation Complete!"
puts "=========================================="
puts ""
puts "Check qpsk_readback.csv for results"
puts "Run: python plot_constellation.py"
puts ""
